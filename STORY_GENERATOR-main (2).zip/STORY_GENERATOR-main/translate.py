from googletrans import Translator

class EnglishToMalayalam:
    """English to Malayalam translation class."""

    @staticmethod
    def translate_story(story):
        """
        Translate the given English story to Malayalam.
        Args:
            story (str): The English story to translate.
        Returns:
            str: Translated story in Malayalam.
        """
        translator = Translator()
        sentences = story.split('. ')  # Split the story into sentences
        translated_sentences = []

        for sentence in sentences:
            if sentence.strip():  # Skip empty sentences
                try:
                    translation = translator.translate(sentence.strip(), dest="ml")
                    translated_sentences.append(translation.text)
                except Exception as e:
                    print(f"Translation failed for sentence: {sentence}\nError: {e}")
                    translated_sentences.append(sentence)  # Fallback to original text

        return '. '.join(translated_sentences)
