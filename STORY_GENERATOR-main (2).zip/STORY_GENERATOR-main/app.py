import streamlit as st
from transformers import BlipProcessor, BlipForConditionalGeneration
from story import generate_story_from_captions
from translate import EnglishToMalayalam
from PIL import Image
import time
import pyperclip

# Streamlit Page Configuration
st.set_page_config(page_title="📖 PICTONARRATE", layout="wide")

st.title("📖 PICTONARRATE: Series of Images to Story in Malayalam")
st.write("This application extracts **captions from images**, generates a **story in English**, and translates it into **Malayalam**.")

# Initialize BLIP model for image captioning
@st.cache_resource
def load_blip_model():
    processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base")
    model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base")
    return processor, model

processor, model = load_blip_model()

# Function to generate captions
def generate_caption(image):
    inputs = processor(images=image, return_tensors="pt")
    out = model.generate(**inputs)
    return processor.decode(out[0], skip_special_tokens=True)

# Upload Images
uploaded_files = st.file_uploader("Upload Images", type=["jpg", "png", "jpeg", "webp"], accept_multiple_files=True)

if uploaded_files:
    st.subheader("📷 Uploaded Images")
    cols = st.columns(len(uploaded_files))
    filenames, captions = [], []

    progress_bar = st.progress(0)
    step = 1 / (len(uploaded_files) + 2)

    for i, file in enumerate(uploaded_files):
        image = Image.open(file).convert("RGB")
        filenames.append(file.name)
        cols[i].image(image, width=150, use_column_width=False)

        # Generate captions only if they haven't been stored
        if f"caption_{i}" not in st.session_state:
            with st.spinner(f"Generating caption for Image {i+1}..."):
                caption = generate_caption(image)
                st.session_state[f"caption_{i}"] = caption  # Store in session state
                time.sleep(1)

        captions.append(st.session_state[f"caption_{i}"])
        progress_bar.progress(int((i + 1) * step * 100))

    combined_caption = ". ".join(captions)

    # Generate Story only if not stored in session state
    if "english_story" not in st.session_state:
        with st.spinner("Generating story in English..."):
            story = generate_story_from_captions(combined_caption)
            st.session_state.english_story = story[0].replace("<sep>", "").strip()
            time.sleep(2)
        progress_bar.progress(int((len(uploaded_files) + 1) * step * 100))

    # Display Extracted Captions
    st.subheader("📖 Extracted Captions")
    for i, caption in enumerate(captions):
        st.write(f"**Image {i+1}:** {caption}")

    # Editable Story in English
    st.subheader("📖 Generated Story (English)")
    edited_story = st.text_area("Edit the generated story before translation:", value=st.session_state.english_story, height=200)

    # Copy & Download Buttons for English Story
    col1, col2 = st.columns(2)
    with col1:
        if st.button("📋 Copy English Story"):
            pyperclip.copy(edited_story)
            st.success("English story copied to clipboard!")

    with col2:
        st.download_button("📥 Download English Story (TXT)", edited_story, "english_story.txt", "text/plain")

    # Translate to Malayalam when user clicks the button
    if st.button("🌍 Translate to Malayalam"):
        if "malayalam_story" not in st.session_state or st.session_state.edited_story != edited_story:
            with st.spinner("Translating to Malayalam..."):
                st.session_state.malayalam_story = EnglishToMalayalam.translate_story(edited_story)
                st.session_state.edited_story = edited_story  # Store latest version

        progress_bar.progress(100)

        # Display Malayalam Story
        st.subheader("📖 Generated Story (Malayalam)")
        st.info(st.session_state.malayalam_story)

        # Copy & Download Buttons for Malayalam Story
        col3, col4 = st.columns(2)
        with col3:
            if st.button("📋 Copy Malayalam Story"):
                pyperclip.copy(st.session_state.malayalam_story)
                st.success("Malayalam story copied to clipboard!")

        with col4:
            st.download_button("📥 Download Malayalam Story (TXT)", st.session_state.malayalam_story, "malayalam_story.txt", "text/plain")

    st.success("🎉 Processing completed successfully!")
